package com.filkom.mycv2.screen

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun daftar() {

}

@Preview
@Composable
fun daftarPreview() {
    daftar()
}